import React, { Component } from 'react';

class Contact extends Component {
    render() {
        return (
            <div>
                <h3>Welcome to the Contact page of Student Management Portal</h3>
            </div>
        );
    }
}

export default Contact;
